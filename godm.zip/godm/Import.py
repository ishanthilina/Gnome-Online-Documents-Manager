import uno
import subprocess
import unohelper
import os
import sys
import imp

from com.sun.star.task import XJobExecutor


file_loc='~/.godm/'
sys.path.append(os.path.dirname(os.path.expanduser(file_loc)))

class Import( unohelper.Base, XJobExecutor ):
    def __init__( self, ctx ):
        self.ctx = ctx
        pass
        

    def trigger( self, args ):
        
        # retrieve the desktop object
        desktop = self.ctx.ServiceManager.createInstanceWithContext(
            "com.sun.star.frame.Desktop", self.ctx )
     
        
     	out=subprocess.Popen(["python", os.path.expanduser(file_loc+'GUI.py'), "import"])
	
       


class Export( unohelper.Base, XJobExecutor ):
    def __init__( self, ctx ):
        self.ctx = ctx
        pass
 
    def trigger( self, args ):
        

        # retrieve the desktop object
        desktop = self.ctx.ServiceManager.createInstanceWithContext(
            "com.sun.star.frame.Desktop", self.ctx )
            
        

        # get current document model
        model = desktop.getCurrentComponent()
        #get the location of the saved file
        filePath=model.getURL()
        

       
       
	subprocess.Popen(["python", os.path.expanduser(file_loc+'GUI.py'), "export", filePath])
	
        
        
class Settings( unohelper.Base, XJobExecutor ):
    def __init__( self, ctx ):
        self.ctx = ctx

        pass
        
    def trigger( self, args ):
        

        subprocess.Popen(["python",os.path.expanduser(file_loc+'GUI.py'), "settings"])
	
        
       
            
g_ImplementationHelper = unohelper.ImplementationHelper()
g_ImplementationHelper.addImplementation(
        Import,
        "name.vojta.openoffice.Import",
        ("com.sun.star.task.Job",),)


g_ImplementationHelper.addImplementation(
        Export,
        "name.vojta.openoffice.Export",
        ("com.sun.star.task.Job",),)
        
g_ImplementationHelper.addImplementation(
        Settings,
        "name.vojta.openoffice.Settings",
        ("com.sun.star.task.Job",),)
        
